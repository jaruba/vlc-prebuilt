--[[--
  SonundCloud track parser
  Made by MarcusD
  
  This is a VLC playlist plugin to be able to play SoundCloud tracks
  An example track link: https://soundcloud.com/destructoid/grimecraft-returns
  
  My GitHub page:     https://github.com/MarcuzD
  My Youtube channel: https://youtube.com/user/mCucc
--]]--

-- SoundCloud ClientID
local cid = "02gUJC0hH2ct1EGOcYXQIzRFU91c72Ea"

-- Probe function.
function probe()
    return ( vlc.access == "https" or vlc.access == "http" )
        and string.match( vlc.path, "(soundcloud%.com/[^/]+/[^?/]+)" )
end

-- http://stackoverflow.com/questions/5958818/loading-serialized-data-into-a-table
function tf(s) 
  t={}
  f, err=loadstring(s)
  if f == nil then error(err) end
  setfenv(f,t)
  f()
  return t
end

-- Parse function.
function parse()
    local line = ""
    while true do
      line = vlc.readline()
      if line == nil then return {} end
      if line:match("webpackJsonp") then break end
    end
    plyid = string.match(line, "\"uri\":\"(https://api%.soundcloud%.com/tracks/%d+)\"")
    if not plyid then error("No plyid") end
    local s, ejj = vlc.stream(plyid .. "?client_id=" .. cid)
    if s == nil then error(ejj) end
    local buf = {}
    local strr = {}
    line = s:readline()
    if not line then error("No line") end
    line = line:gsub("%[", "{"):gsub("%]", "}"):gsub("([{,])\"(.-)\":", "%1[\"%2\"]=")
    strr = tf("main=" .. line)
    local v = strr.main
    if v == nil then error("No muzik") end

    return {{
            path = (v.stream_url .. "?client_id=" .. cid),
            name = v.title,
            arturl = (v.artwork_url and v.artwork_url or v.user.artwork_url),
            title = v.title,
            artist = (v.user.username .. " (" .. v.user.permalink.. ")"),
            genre = v.genre,
            copyright = v.license,
            description = v.description,
            date = v.created_at,
            url = vlc.access .. "://" .. v.permalink_url,
            meta = 
            {
              ["tag list"] = v.tag_list,
              ["creation time"] = v.created_at
            }
           }}
end